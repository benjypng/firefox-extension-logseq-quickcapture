This Chrome extension does not collect any information about you, your browser or any information related to you.

It simply extracts the url, title and selected text (if any) and sends it to Logseq using the quickCapture callback.

For more information, please visit https://github.com/hkgnp/chrome-extension-logseq-quickcapture.
